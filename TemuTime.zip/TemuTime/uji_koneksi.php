<?php
include 'config/koneksi.php';
echo "Koneksi berhasil!";
?>
